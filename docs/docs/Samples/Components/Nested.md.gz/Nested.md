﻿<div class="row">
    <div class="col-6">
        <h6 class="text-center fw-bold">Sortable</h6>
        <SortableWrapper OnDataChanged="@(() => InvokeAsync(StateHasChanged))">
            <NestedRecursive Items="items" Depth="1" />
        </SortableWrapper>
    </div>
    <div class="col-6">
        <h6 class="text-center fw-bold">Result</h6>
        <pre class="bg-info">
            @System.Text.Json.JsonSerializer.Serialize(items, new JsonSerializerOptions
            {
                WriteIndented = true,
            });
        </pre>
    </div>
</div>
@code {
    private List<NestedModel> items = new List<NestedModel>
    {
        new NestedModel{ Data = "Item 1.1"},
        new NestedModel{ Data = "Item 1.2", Children = new List<NestedModel>()
        {
              new NestedModel{ Data = "Item 1.2-1"},
              new NestedModel{ Data = "Item 1.2-2", Children = new List<NestedModel>(){
                  new NestedModel{ Data = "Item 1.2-2.1"},
                  new NestedModel{ Data = "Item 1.2-2.2"},
                  new NestedModel{ Data = "Item 1.2-2.3"},
                  new NestedModel{ Data = "Item 1.2-2.4"},
              }},
              new NestedModel{ Data = "Item 1.2.3"},
              new NestedModel{ Data = "Item 1.2.4"},
        }},
        new NestedModel{ Data = "Item 1.3"},
        new NestedModel{ Data = "Item 1.4", Children = new List<NestedModel>()
        {
              new NestedModel{ Data = "Item 1.4.1"},
              new NestedModel{ Data = "Item 1.4.2"},
              new NestedModel{ Data = "Item 1.4.3"},
              new NestedModel{ Data = "Item 1.4.4"},
        }},
        new NestedModel{ Data = "Item 1.5"},
    };
}
