﻿<SortableWrapper>
    <Sortable TItem="string" Items="items" Context="item" Options="_options">
        <Template>
            <div class="grid-square py-0">
                <div class="mx-auto w-50 h-100 bg-primary text-center fw-bold">
                    @item
                </div>
            </div>
        </Template>
    </Sortable>
</SortableWrapper>
@code {
    object _options = new
    {
        swapThreshold = 0.5M,
        animation = 150,
        ghostClass = "blue-background-class"
    };
    private List<string> items = new List<string>();

    protected override void OnInitialized()
    {
        for (var i = 1; i < 21; ++i)
        {
            items.Add($"{i}");
        }
    }
}
