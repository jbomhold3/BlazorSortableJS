﻿<SortableWrapper>
    <Sortable TItem="string" Items="items" Context="item" Options="_options">
        <Template>
            <div class="grid-square">@item</div>
        </Template>
    </Sortable>
</SortableWrapper>
@code {
    object _options = new
    {
        animation = 150,
        ghostClass = "blue-background-class"
    };
    private List<string> items = new List<string>();

    protected override void OnInitialized()
    {
        for (var i = 1; i < 21; ++i)
        {
            items.Add($"Item {i}");
        }
    }
}
