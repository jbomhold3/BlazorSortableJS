﻿<div class="row">
    <SortableWrapper OnDataChanged="@(() => InvokeAsync(StateHasChanged))">
        <div class="col-4">
            <h6 class="text-center fw-bold">Set 1</h6>
            <Sortable TItem="string" Items="items" Class="list-group" Options="_options">
                <Template Context="item">
                    <div class="list-group-item">@item</div>
                </Template>
            </Sortable>
        </div>
        <div class="col-4">
            <h6 class="text-center fw-bold">Set 2</h6>
            <Sortable TItem="string" Items="items2" Class="list-group" Options="_options">
                <Template Context="item">
                    <div class="list-group-item tinted">@item</div>
                </Template>
            </Sortable>
        </div>
    </SortableWrapper>
    <div class="col-4">
        <h6 class="text-center fw-bold">Result</h6>
        Set 1
        <pre class="bg-info">
            @System.Text.Json.JsonSerializer.Serialize(items, new JsonSerializerOptions
            {
                WriteIndented = true,
            });
        </pre>
        Set 2
        <pre class="bg-info">
            @System.Text.Json.JsonSerializer.Serialize(items2, new JsonSerializerOptions
            {
                WriteIndented = true,
            });
        </pre>
    </div>
</div>
@code {
    object _options = new
    {
        group = new {
            name = "shared",
            pull = "clone" 
        },
        animation = 150,
        ghostClass = "blue-background-class"
    };
    private List<string> items = new List<string>
    {
        "Item 1-1",
        "Item 1-2",
        "Item 1-3",
    };
    private List<string> items2 = new List<string>
    {
        "Item 2-1",
        "Item 2-2",
        "Item 2-3",
    };
}