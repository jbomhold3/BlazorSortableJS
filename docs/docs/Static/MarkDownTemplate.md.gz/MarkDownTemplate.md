﻿## Page Heading
#### Component \<Name\>
See [shared](layout/shared) for additional parameters    
:::

| Parameter | Type | Valid | Remarks/Output | 
|-----------|------|-------|----------------|
|           |      |       |                | {.table-striped .p-2}

:::

Samples must have a line above and below. Listed are two examples one with custom classes for the wrapper the other without

{{sample=Components/Alerts/Alerts1}}

{{sample=Components/Alerts/Alerts1;classListNoDots}}

{.DivClassList}
:::
This is a custom div
:::